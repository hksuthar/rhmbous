#!/bin/sh
../dudac/dudac -u -w .

